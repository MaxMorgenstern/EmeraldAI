 This folder contains log-files.
