Folder for person identification.
This folder also contains "Unknown" data.
