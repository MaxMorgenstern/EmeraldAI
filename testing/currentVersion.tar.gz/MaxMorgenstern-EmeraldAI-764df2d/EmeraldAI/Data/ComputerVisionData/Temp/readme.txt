This folder contains temporary image data.
