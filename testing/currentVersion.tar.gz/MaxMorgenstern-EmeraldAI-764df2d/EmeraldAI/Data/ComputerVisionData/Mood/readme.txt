Folder for mood detection
