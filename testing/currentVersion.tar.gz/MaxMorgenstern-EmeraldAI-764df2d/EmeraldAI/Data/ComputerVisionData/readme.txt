 This folder contains datasets for computer vision.
