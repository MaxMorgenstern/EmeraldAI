#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
reload(sys)
sys.setdefaultencoding('utf-8')

# TODO: Install process
# Ensure all dependencies are present and check environment

# Clear Database and add Basic Data - Maybe link to FactoryReset.py


# copy config files
"""
import shutil
shutil.copy2('/dir/file.ext', '/new/dir/newname.ext')
"""
