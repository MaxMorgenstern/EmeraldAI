This folder contains all main processes as well as an install and reset script.

Please refer to this readme regarding the purpose of each file.


# TODO

Brain.py
FactoryReset.py
Install.py
Setup.py


Cron_Formalizer.py
 Runs Once per day
