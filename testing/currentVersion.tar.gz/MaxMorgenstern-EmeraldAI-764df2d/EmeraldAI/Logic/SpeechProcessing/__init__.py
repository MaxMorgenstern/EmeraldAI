__all__ = ["Google", "Microsoft"]
