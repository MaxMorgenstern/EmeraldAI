Folder for person identification.
This folder also contains test data.
