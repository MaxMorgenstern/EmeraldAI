import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
reload(sys)
sys.setdefaultencoding('utf-8')

from EmeraldAI.Entities.PredictionObject import PredictionObject


po = PredictionObject(None,None,None,None)

print po




from EmeraldAI.Logic.ComputerVision.ComputerVision import ComputerVision

cv = ComputerVision()



cv.TrainModel("Person", "350x350")
