__all__ = ["Detector", "Trainer"]
