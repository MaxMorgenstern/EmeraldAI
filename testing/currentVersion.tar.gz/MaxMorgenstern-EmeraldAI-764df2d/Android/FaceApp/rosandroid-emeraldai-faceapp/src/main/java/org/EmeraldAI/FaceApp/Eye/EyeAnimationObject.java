package org.EmeraldAI.FaceApp.Eye;

/**
 * Created by maximilianporzelt on 16.04.17.
 */

public class EyeAnimationObject {
    public String AnimationObject;
    public String AnimationName;
    public String Position;
    public boolean IntermediateAnimation;
    public int MinDelayAfterAnimation;
}
